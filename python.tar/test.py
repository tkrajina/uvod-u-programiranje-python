def IspisiPoruku( s1, s2, s3, za ):
	""" Vraca string s porukom je li polaznik koji je imao:
	 s1 tocno rjesen zadatak iz prve grupe,
	 s2 tocno rjesen zadatak iz druge grupe,
	 s3 tocno rjesen zadatak iz trece grupe
	...prosao test.
	Ako je varijabla 'za' jednaka "auto" onda se racuna kao za
	polaznika za dozvou za voznju automobila, inace
	za polaznika voznje s mopedom
	"""
	bodovi = s1 + s2 * 2 + s3 * 3
	temp = "" # varijabla koja sadrzi prazan string
	if za == "auto":
		if bodovi >= 26:
			temp = "Prosli ste"
		else:
			temp = "Niste prosli"
	else:
		if bodovi >= 24:
			temp = "Prosli ste"
		else:
			temp = "Niste prosli"
	return temp
	
print IspisiPoruku( 5, 4, 4, "auto" )
print IspisiPoruku( 5, 4, 4, "motor" )

